package de.uni.bielefeld.sc.hterhors.psink.scio.semanticmr.normalizer.interpreter.struct;

public interface ISingleUnit extends IUnit {


	public double getFactor();
}
